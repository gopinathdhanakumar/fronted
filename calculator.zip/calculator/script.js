var sum="";
function valueof(num)
{
  if(num=="c")
  {
     document.getElementById("input").value="";
     sum="";
   }
   else if(num=="=")
   {
      document.getElementById("input").value=
      eval(document.getElementById("input").value);
      sum=eval(document.getElementById("input").value);

   }
   else
   {  
  sum=sum+num;
  document.getElementById("input").value=sum;
   }
}

$(document).ready(function(){
   $("#zoomin").click(function(){
     $("#valueCalc").animate({
       left: '+=250px',
       height: '+=100px',
       width: '+=100px'
     });
     $("button").animate({
      left: '+=40px',
      height: '+=20px',
      width: '+=20px'
    });
    $("input").animate({
      left: '+=40px',
      height: '+=20px',
      width: '+=20px'
    });
   });
   $("#zoomout").click(function(){
      $("#valueCalc").animate({
         left: '-=250px',
         height: '-=100px',
         width: '-=100px'
       });
       $("button").animate({
        left: '-=40px',
        height: '-=20px',
        width: '-=20px'
      });
      $("input").animate({
        left: '-=40px',
        height: '-=20px',
        width: '-=20px'
      });
    });
 });
function valid()
{
   var regex = /^[a-zA-Z]+$/;
   var data=document.getElementById("input").value;
   if(regex.test(data)==true)
   {
      document.getElementById("input").value="";
   }

}