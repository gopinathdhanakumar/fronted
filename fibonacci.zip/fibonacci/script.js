var k=1;
var var1=0, var2=1;
var myTimer=null;
var sum=0;
function Start()
{
 
   myTimer = setInterval(fibonaci, 1000);
   
}
function Stop()
{
  //console.log(sum);
  clearInterval(myTimer);
}
function fibonaci( )

{
  
  for(var i=0;i<1;i++)
  {
document.getElementById("fibonacci").value=sum;
 console.log(k+"th  fibo value"+sum);
 k=k+1;
sum=Number(var1)+Number(var2);
var1=Number(var2);
var2=Number(sum);
  }
  
  
  
 // return k+k;
}