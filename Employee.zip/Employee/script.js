var request;
function openCrud(evt, process) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(process).style.display = "block";
    evt.currentTarget.className += " active";
    if (process == "Delete") {
        getDeleteId();
    }
    else if (process == "Update") {
        getUpdate();
        // var styler = document.getElementsByClassName("update");
        //styler.style.display = "none";
    }
    else (process == "Display")
    {
        getAllEmployee();
    }


}
function addDetails() {
    FuncValidate();
    console.log(document.getElementById('name').value);
    console.log(document.getElementById('age').value);
    console.log(document.getElementById('role').value);

    //event.preventDefault();
    document.getElementById('message').innerHTML = "checking";

    const url = "http://localhost:1111/Employee//addEmployee";
    const gpsData = {
        "id": document.getElementById('id').value,
        "latitude": document.getElementById('latitude').value,
        "longtitude": document.getElementById('longitude').value,
    }
    const addressdata = {
        "address": document.getElementById('address').value,
        "city": document.getElementById('city').value,
        "state": document.getElementById('state').value,
        "pin": document.getElementById('pin').value,
        "gps": gpsData
    };
    const data = {
        "name": document.getElementById('name').value,
        "age": document.getElementById('age').value,
        "role": document.getElementById('role').value,
        "address": addressdata
    };
    const other_params = {
        headers: { "content-type": "application/json; charset=UTF-8" },
        body: JSON.stringify(data),
        method: "POST",
        mode: "cors"
    };

    fetch(url, other_params)
        .then(function (response) {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error("Could not reach the API: " + response.statusText);
            }
        }).then(function (data) {
            document.getElementById("message").innerHTML = data.encoded;
        }).catch(function (error) {
            document.getElementById("message").innerHTML = error.message;
        });

    return true;
}
function getDeleteId() {
    $.ajax(
        {
            url: 'http://localhost:1111/Employee/displayEmployee',
            type: 'GET',
            dataType: 'json',
            success: function (data, textStatus, xhr) {
                console.log(data);
                var temp = " <label>Enter Id:</label><select id='getIdValue'>";
                for (i = 0; i < data.length; i++) {
                    temp += "<option value=" + data[i].id + ">" + data[i].id + "</option>";
                }
                var value = temp + "</select>";
                console.log(temp);

                document.getElementById("getIdDelete").innerHTML = value;
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log('Error in Operation');
            }

        }
    )

}
function DeleteById() {
    var id = document.getElementById('getIdValue').value;
    $.ajax(
        {
            url: 'http://localhost:1111/Employee/deleteEmployee/' + id,
            method: 'DELETE',
            success: function () {
                alert("Deleted SucessFully");
                getDeleteId();
            },
            error: function (error) {
                console.log('Error in Operation');
            }

        }
    )

}
var update;
function getUpdate() {
    $.ajax(
        {
            url: 'http://localhost:1111/Employee/displayEmployee',
            type: 'GET',
            dataType: 'json',
            success: function (data, textStatus, xhr) {
                console.log(data);
                update = data;
                console.log(update);
                var temp = " <label>Enter Id:</label><select id='getUpdateIdValue'>";
                for (i = 0; i < data.length; i++) {
                    temp += "<option value=" + data[i].id + ">" + data[i].id + "</option>";
                }
                console.log(temp);
                var value = temp + "</select>";
                document.getElementById("getId").innerHTML = value;
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log('Error in Operation');
            }

        }
    )

}
function getUpdateId() {
    document.getElementById('displayUpdate').style.display = "block";

    var id = document.getElementById("getUpdateIdValue").value;
    for (i = 0; i < update.length; i++) {
        if (update[i].id == id) {
            document.getElementById('gpsid').value = update[i].address.gps.id;
            document.getElementById('LatitudeUpdate').value = update[i].address.gps.latitude;
            document.getElementById('longitudeUpdate').value = update[i].address.gps.longtitude;
            document.getElementById('addressUpdate').value = update[i].address.address;
            document.getElementById('cityUpdate').value = update[i].address.city;
            document.getElementById('stateUpdate').value = update[i].address.state;
            document.getElementById('pinUpdate').value = update[i].address.pin;
            document.getElementById('addressid').value = update[i].address.id;
            document.getElementById('nameUpdate').value = update[i].name;
            document.getElementById('ageUpdate').value = update[i].age;
            document.getElementById('roleUpdate').value = update[i].role;
            document.getElementById('idUpdate').value = update[i].id;

        }
    }



}
function updateValue() {


    // event.preventDefault();
    // document.getElementById('message').innerHTML = "checking";
    console.log("welcome");

    const gpsData = {
        "id": document.getElementById('gpsid').value,
        "latitude": document.getElementById('LatitudeUpdate').value,
        "longtitude": document.getElementById('longitudeUpdate').value,
    }
    const addressdata = {
        "id": document.getElementById('addressid').value,
        "address": document.getElementById('addressUpdate').value,
        "city": document.getElementById('cityUpdate').value,
        "state": document.getElementById('stateUpdate').value,
        "pin": document.getElementById('pinUpdate').value,
        "gps": gpsData
    };
    const data = {
        "id": document.getElementById('idUpdate').value,
        "name": document.getElementById('nameUpdate').value,
        "age": document.getElementById('ageUpdate').value,
        "role": document.getElementById('roleUpdate').value,
        "address": addressdata
    };
    $.ajax({
        type: "PUT",
        contentType: "application/json",
        url: "http://localhost:1111/Employee/updateEmployee",
        data: JSON.stringify(data),
        dataType: 'json',
        success: function (result) {
            console.log(result);
            alert("Successfully Updated!!");
            document.getElementById('displayUpdate').style.display = "none";
            getUpdate();

        },
        error: function (e) {
            console.log(e);
        }
    })

}
function getAllEmployee() {
    var url = "http://localhost:1111/Employee/displayEmployee";
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url, true);
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var employee = JSON.parse(xmlhttp.responseText);
            var top = ` <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Age</th>
            <th>Role</th>
            <th>Address</th>
            <th>City</th>
            <th>State</th>
            <th>Pin</th>
            <th>Latitude</th>
            <th>Longutitude</th>
          </tr>`;
            var main = "";
            console.log(employee);
            for (i = 0; i < employee.length; i++) {
                main += "<tr><td>" + employee[i].id + "</td><td>" + employee[i].name + "</td><td>" + employee[i].age + "</td><td>" + employee[i].role + "</td><td>" + employee[i].address.id + "</td><td>" + "</td><td>" + employee[i].address.address + "</td><td>" + employee[i].address.city + "</td><td>" + employee[i].address.state + "</td><td>" + employee[i].address.pin + "</td><td>" + employee[i].address.gps.latitude + "</td><td" + employee[i].address.gps.longtitude + "</td></tr>";
            }
            var table = top + main;
            document.getElementById("displayTable").innerHTML = table;

        }
    };
    xmlhttp.send();
}
function valid() {
    var uname = document.getElementById("name").value;
    var age = document.getElementById("age").value;
    var role = document.getElementById("role").value;
    var address = document.getElementById("address").value;
    var city = document.getElementById("city").value;
    var state = document.getElementById("state").value;
    var pin = document.getElementById("pin").value;
    var longitude = document.getElementById("longitude").value;
    var latitude = document.getElementById("latitude").value;
    var patcheck = new RegExp("^[0-9]");
    if ( (uname === "")) {
        document.getElementById("div1").innerHTML = "Only Alphabets";
        document.getElementById("div1").style.color = "Red";

    }
    else {
        document.getElementById("div1").innerHTML = "";
    }

    if (age === "") {
        document.getElementById("div2").innerHTML = "Enter a value";
        document.getElementById("div2").style.color = "Red";

    }
    else {
        document.getElementById("div2").innerHTML = "";

    }
    if (!patcheck.test(role)) {
       document.getElementById("div13").innerHTML = "Enter a value";
       document.getElementById("div13").style.color = "Red";

    }
    else {
        document.getElementById("div3").innerHTML = "";

    }
}
function FuncValidate() {

    if (document.getElementById("name").value == "") {
        alert("Please enter the name");
        document.getElementById("name").focus();
        document.getElementById("message").innerHTML = "Please Enter Name";
        return false;
    }

    if (document.getElementById("age").value == "") {
        alert("Please enter the age");
        document.getElementById("age").focus();
        return false;
    }

    if (document.getElementById("role").value == "") {
        alert("Please enter the role");
        document.getElementById("role").focus();
        return false;
    }
    return true;
}



// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();