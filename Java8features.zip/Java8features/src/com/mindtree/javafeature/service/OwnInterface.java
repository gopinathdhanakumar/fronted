package com.mindtree.javafeature.service;

import java.util.ArrayList;

import com.mindtree.javafeature.model.Item;

public interface OwnInterface {

	void print(Item i);
}
