package com.mindtree.javafeature.model;

public class Item {
	private int id;
	private String itemname;
	private int itemprice;
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Item(int id, String itemname, int itemprice) {
		super();
		this.id = id;
		this.itemname = itemname;
		this.itemprice = itemprice;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public int getItemprice() {
		return itemprice;
	}
	public void setItemprice(int itemprice) {
		this.itemprice = itemprice;
	}
	

}
