package com.mindtree.javafeature.model;

public class Product {

	private int id;
	private String productName;
	private int productPrice;
	private int productStock;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Product(int id, String productName, int productPrice, int productStock) {
		super();
		this.id = id;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productStock = productStock;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public int getProductStock() {
		return productStock;
	}
	public void setProductStock(int productStock) {
		this.productStock = productStock;
	}
	
}
